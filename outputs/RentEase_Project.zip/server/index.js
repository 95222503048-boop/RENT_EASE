import 'express-async-errors';
import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import multer from 'multer';
import { v2 as cloudinary } from 'cloudinary';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { User, Product, Rental } from './models.js';

const app = express();
const port = Number(process.env.PORT || 10000);
const here = path.dirname(fileURLToPath(import.meta.url));
const isProduction = process.env.NODE_ENV === 'production';
const origins = process.env.CLIENT_ORIGIN?.split(',').map((x) => x.trim()).filter(Boolean);
const proxyHops = Number(process.env.TRUST_PROXY ?? 1);
app.set('trust proxy', isProduction && Number.isInteger(proxyHops) && proxyHops > 0 ? proxyHops : false);
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: { directives: { imgSrc:["'self'",'data:','https:'], upgradeInsecureRequests:isProduction ? [] : null } } }));
if (origins?.length) app.use(cors({ origin:origins }));
app.use(express.json({ limit:'100kb', strict:true }));
const fail = (res, status, message) => res.status(status).json({ error:message });
const apiLimiter = rateLimit({ windowMs:15*60*1000, limit:300, standardHeaders:true, legacyHeaders:false, message:{ error:'Too many requests. Please try again later.' } });
const authLimiter = rateLimit({ windowMs:15*60*1000, limit:10, standardHeaders:true, legacyHeaders:false, message:{ error:'Too many sign-in attempts. Please wait and try again.' } });
const imageLimiter = rateLimit({ windowMs:15*60*1000, limit:20, standardHeaders:true, legacyHeaders:false, message:{ error:'Too many image uploads. Please try again later.' } });
app.use('/api', apiLimiter);
app.use('/api/auth', authLimiter);

const imageUpload = multer({
  storage:multer.memoryStorage(),
  limits:{ fileSize:5*1024*1024, files:1, fields:0, parts:1 },
  fileFilter:(_req,file,cb) => ['image/jpeg','image/png','image/webp','image/avif'].includes(file.mimetype) ? cb(null,true) : cb(new Error('Unsupported image type'))
});
cloudinary.config({ cloud_name:process.env.CLOUDINARY_CLOUD_NAME, api_key:process.env.CLOUDINARY_API_KEY, api_secret:process.env.CLOUDINARY_API_SECRET, secure:true });
const cloudinaryReady = () => Boolean(process.env.CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_API_KEY && process.env.CLOUDINARY_API_SECRET);
const uploadImage = (buffer) => new Promise((resolve,reject) => {
  cloudinary.uploader.upload_stream({ folder:'rentease/products', resource_type:'image', allowed_formats:['jpg','jpeg','png','webp','avif'] }, (err,result) => err ? reject(err) : resolve(result)).end(buffer);
});
function cleanText(value, maxLength) {
  if (typeof value !== 'string') return null;
  return value.normalize('NFKC').replace(/<[^>]*>/g,'').replace(/[\u0000-\u001f\u007f]/g,' ').trim().slice(0,maxLength);
}
function validEmail(value) { return typeof value === 'string' && value.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim()); }
function validId(value) { return typeof value === 'string' && /^[0-9a-f]{24}$/i.test(value); }
function cleanPhone(value) {
  if (typeof value !== 'string') return null;
  const phone = value.trim().replace(/[\s().-]/g,'');
  return /^\+?[0-9]{7,15}$/.test(phone) ? phone : null;
}
function parseMoney(value) {
  if (typeof value === 'number') return Number.isFinite(value) ? value : null;
  if (typeof value !== 'string' || !/^\d+(?:\.\d{1,2})?$/.test(value.trim())) return null;
  const amount = Number(value);
  return Number.isFinite(amount) ? amount : null;
}
function rentalView(r) {
  const start = r.approvedAt ? new Date(r.approvedAt) : null;
  const stop = r.returnedAt ? new Date(r.returnedAt) : new Date();
  const days = start && !['pending'].includes(r.status) ? Math.floor(Math.max(0,stop-start)/86_400_000) : 0;
  const dailyRate = r.monthlyRent/30;
  const customer = r.customer?.email ? { id:r.customer.id, name:r.customer.name, email:r.customer.email, phone:r.customer.phone } : r.customer;
  return { ...r.toObject(), customer, days, dailyRate, accruedRent:Math.round(days*dailyRate*100)/100 };
}
const safeUser = (u) => ({ id:u.id, name:u.name, email:u.email, phone:u.phone, role:u.role });
const safeAdminProfile = (u) => ({ id:u.id, name:u.name, storeName:u.storeName, storeDescription:u.storeDescription, storeCity:u.storeCity, storePhone:u.storePhone, storeLogo:u.storeLogo });
const auth = async (req,res,next) => {
  try {
    const token = (req.headers.authorization || '').replace(/^Bearer\s+/i,'');
    if (!token) return fail(res,401,'Please sign in to continue.');
    const payload = jwt.verify(token,process.env.JWT_SECRET,{ algorithms:['HS256'] });
    req.user = await User.findById(payload.sub).select('name email phone role storeName storeDescription storeCity storePhone storeLogo');
    if (!req.user) return fail(res,401,'Account not found.');
    next();
  } catch { return fail(res,401,'Your session is invalid or has expired. Please sign in again.'); }
};
const allowRoles = (...roles) => (req,res,next) => roles.includes(req.user?.role) ? next() : fail(res,403,'You are not allowed to use this feature.');
const customerOnly = allowRoles('customer');
const adminOnly = allowRoles('admin');
const developerOnly = allowRoles('developer');
const tokenFor = (user) => jwt.sign({ sub:user.id },process.env.JWT_SECRET,{ expiresIn:'7d', algorithm:'HS256' });

app.get('/api/health',(_req,res) => {
  const ready = mongoose.connection.readyState === 1;
  res.status(ready ? 200 : 503).json({ ok:ready });
});
app.post('/api/auth/register',async (req,res) => {
  const name=cleanText(req.body?.name,80), email=typeof req.body?.email==='string'?req.body.email.trim().toLowerCase():'', password=req.body?.password, phone=cleanPhone(req.body?.phone);
  if (!name || name.length<2 || !validEmail(email) || typeof password!=='string' || password.length<8 || Buffer.byteLength(password,'utf8')>72 || !phone) return fail(res,400,'Enter a valid name, email, phone number, and password (8–72 bytes).');
  if (await User.exists({ email })) return fail(res,409,'An account with this email already exists.');
  const user=await User.create({ name,email,phone,passwordHash:await bcrypt.hash(password,12),role:'customer' });
  res.status(201).json({ token:tokenFor(user),user:safeUser(user) });
});
app.post('/api/auth/login',async (req,res) => {
  const email=typeof req.body?.email==='string'?req.body.email.trim().toLowerCase():'', password=req.body?.password;
  if (!validEmail(email) || typeof password!=='string' || Buffer.byteLength(password,'utf8')>72) return fail(res,401,'Email or password is incorrect.');
  const user=await User.findOne({ email });
  if (!user || !(await bcrypt.compare(password,user.passwordHash))) return fail(res,401,'Email or password is incorrect.');
  res.json({ token:tokenFor(user),user:safeUser(user) });
});
app.get('/api/auth/me',auth,(req,res) => res.json({ user:safeUser(req.user) }));

app.get('/api/admins',async (_req,res) => {
  const [admins,customerGroups,productCounts]=await Promise.all([
    User.find({ role:'admin',storeName:{ $type:'string',$ne:'' },storeDescription:{ $type:'string',$ne:'' },storeCity:{ $type:'string',$ne:'' },storePhone:{ $type:'string',$ne:'' } }).select('name storeName storeDescription storeCity storePhone storeLogo').limit(200).lean(),
    Rental.aggregate([{ $group:{ _id:{ owner:'$owner',customer:'$customer' } } },{ $group:{ _id:'$_id.owner',count:{ $sum:1 } } }]),
    Product.aggregate([{ $match:{ active:true } },{ $group:{ _id:'$owner',count:{ $sum:1 } } }])
  ]);
  const customers=new Map(customerGroups.map((x)=>[String(x._id),x.count]));
  const products=new Map(productCounts.map((x)=>[String(x._id),x.count]));
  const result=admins.map((a)=>({ id:String(a._id),name:a.name,storeName:a.storeName,storeDescription:a.storeDescription,storeCity:a.storeCity,storePhone:a.storePhone,storeLogo:a.storeLogo,customerCount:customers.get(String(a._id))||0,productCount:products.get(String(a._id))||0 }));
  result.sort((a,b)=>b.customerCount-a.customerCount || a.storeName.localeCompare(b.storeName));
  res.set('Cache-Control','public, max-age=20, stale-while-revalidate=40');
  res.json(result);
});
app.get('/api/products',async (req,res) => {
  const { adminId }=req.query;
  if (!validId(adminId)) return fail(res,400,'Choose a valid rental shop.');
  const shop=await User.exists({ _id:adminId,role:'admin',storeName:{ $type:'string',$ne:'' },storeDescription:{ $type:'string',$ne:'' },storeCity:{ $type:'string',$ne:'' },storePhone:{ $type:'string',$ne:'' } });
  if (!shop) return fail(res,404,'Rental shop not found.');
  const products=await Product.find({ owner:adminId,active:true }).select('name category description monthlyRent deposit image available').sort({ createdAt:-1 }).limit(60).lean();
  res.set('Cache-Control','public, max-age=20, stale-while-revalidate=40');
  res.json(products);
});
app.post('/api/rentals',auth,customerOnly,async (req,res) => {
  const { productId }=req.body||{}, deliveryAddress=cleanText(req.body?.deliveryAddress,500), phone=cleanPhone(req.body?.phone);
  if (!validId(productId) || !deliveryAddress || deliveryAddress.length<5 || !phone) return fail(res,400,'Choose a product, enter a valid delivery address, and add a phone number for the shop to call.');
  const product=await Product.findOneAndUpdate({ _id:productId,active:true,available:true },{ $set:{ available:false } },{ new:true });
  if (!product) return fail(res,409,'This item was just reserved. Please choose another one.');
  const shop=await User.findOne({ _id:product.owner,role:'admin' }).select('storeName');
  if (!shop) { await Product.findByIdAndUpdate(product.id,{ $set:{ available:true } }); return fail(res,409,'This rental shop is unavailable.'); }
  try {
    await User.findByIdAndUpdate(req.user.id,{ $set:{ phone } });
    const rental=await Rental.create({ customer:req.user.id,owner:product.owner,storeName:shop.storeName,product:product.id,productName:product.name,category:product.category,monthlyRent:product.monthlyRent,deposit:product.deposit,deliveryAddress });
    res.status(201).json({ rental:rentalView(rental) });
  } catch(error) { await Product.findByIdAndUpdate(product.id,{ $set:{ available:true } }); throw error; }
});
app.get('/api/rentals/mine',auth,customerOnly,async (req,res) => {
  const rentals=await Rental.find({ customer:req.user.id }).sort({ createdAt:-1 }).limit(100);
  res.json(rentals.map(rentalView));
});
app.patch('/api/rentals/:id/return',auth,customerOnly,async (req,res) => {
  if (!validId(req.params.id)) return fail(res,400,'Invalid rental ID.');
  const rental=await Rental.findOneAndUpdate({ _id:req.params.id,customer:req.user.id,status:'active' },{ $set:{ status:'return_requested' } },{ new:true });
  if (!rental) return fail(res,404,'Active rental not found.');
  res.json({ rental:rentalView(rental) });
});

app.get('/api/admin/profile',auth,adminOnly,(req,res) => res.json({ profile:safeAdminProfile(req.user) }));
app.patch('/api/admin/profile',auth,adminOnly,async (req,res) => {
  const name=cleanText(req.body?.name,80),storeName=cleanText(req.body?.storeName,100),storeDescription=cleanText(req.body?.storeDescription,1000),storeCity=cleanText(req.body?.storeCity,100),storePhone=cleanPhone(req.body?.storePhone);
  if (!name || name.length<2 || !storeName || storeName.length<2 || !storeDescription || !storeCity || !storePhone) return fail(res,400,'Complete your name, shop name, description, city, and contact phone.');
  const updated=await User.findByIdAndUpdate(req.user.id,{ $set:{ name,storeName,storeDescription,storeCity,storePhone } },{ new:true,runValidators:true }).select('name email phone role storeName storeDescription storeCity storePhone storeLogo');
  res.json({ profile:safeAdminProfile(updated) });
});
app.get('/api/admin/products',auth,adminOnly,async (req,res) => {
  const products=await Product.find({ owner:req.user.id }).sort({ createdAt:-1 }).limit(100).lean();
  res.json(products);
});
app.post('/api/admin/images',auth,adminOnly,imageLimiter,imageUpload.single('image'),async (req,res) => {
  if (!cloudinaryReady()) return fail(res,503,'Image uploads are not configured yet.');
  if (!req.file) return fail(res,400,'Choose a JPEG, PNG, WebP, or AVIF image up to 5 MB.');
  const result=await uploadImage(req.file.buffer);
  const url=cloudinary.url(result.public_id,{ secure:true,transformation:[{ width:900,height:700,crop:'limit',quality:'auto',fetch_format:'auto' }] });
  res.status(201).json({ url,publicId:result.public_id });
});
app.post('/api/admin/products',auth,adminOnly,async (req,res) => {
  const name=cleanText(req.body?.name,100),category=req.body?.category,description=cleanText(req.body?.description??'',1000),monthlyRent=parseMoney(req.body?.monthlyRent),deposit=req.body?.deposit===undefined||req.body?.deposit===''?0:parseMoney(req.body.deposit),image=typeof req.body?.image==='string'?req.body.image.trim():'',imagePublicId=typeof req.body?.imagePublicId==='string'?req.body.imagePublicId.trim():'';
  if (!name || !['Furniture','Appliances'].includes(category) || description===null || monthlyRent===null || monthlyRent<=0 || monthlyRent>10_000_000 || deposit===null || deposit<0 || deposit>10_000_000 || !image.startsWith('https://') || !imagePublicId.startsWith('rentease/products/')) return fail(res,400,'Check the product details and upload its image to Cloudinary.');
  const product=await Product.create({ owner:req.user.id,name,category,description,monthlyRent,deposit,image,imagePublicId });
  res.status(201).json({ product });
});
app.patch('/api/admin/products/:id',auth,adminOnly,async (req,res) => {
  if (!validId(req.params.id)) return fail(res,400,'Invalid product ID.');
  const body=req.body||{},allowed=new Set(['available','active']);
  if (!Object.keys(body).length || Object.keys(body).some((key)=>!allowed.has(key)) || Object.values(body).some((value)=>typeof value!=='boolean')) return fail(res,400,'Only availability and listing status can be changed here.');
  if (body.available===true && await Rental.exists({ product:req.params.id,owner:req.user.id,status:{ $in:['pending','active','maintenance','return_requested'] } })) return fail(res,409,'This item is attached to an open rental.');
  const product=await Product.findOneAndUpdate({ _id:req.params.id,owner:req.user.id },{ $set:body },{ new:true,runValidators:true });
  if (!product) return fail(res,404,'Product not found.');
  res.json({ product });
});
app.get('/api/admin/rentals',auth,adminOnly,async (req,res) => {
  const rentals=await Rental.find({ owner:req.user.id }).populate('customer','name email phone').sort({ createdAt:-1 }).limit(200);
  res.json(rentals.map(rentalView));
});
app.patch('/api/admin/rentals/:id',auth,adminOnly,async (req,res) => {
  if (!validId(req.params.id)) return fail(res,400,'Invalid rental ID.');
  const { status,trackingNote }=req.body||{};
  if (!['active','maintenance','return_requested','returned'].includes(status) || (trackingNote!==undefined && typeof trackingNote!=='string')) return fail(res,400,'Choose a valid status and tracking note.');
  const rental=await Rental.findOne({ _id:req.params.id,owner:req.user.id });
  if (!rental) return fail(res,404,'Rental not found.');
  if (rental.status==='returned') return fail(res,409,'This rental is already closed.');
  if (status==='active' && rental.status==='pending') rental.approvedAt=new Date();
  if (status==='returned') rental.returnedAt=new Date();
  rental.status=status;
  if (trackingNote!==undefined) rental.trackingNote=cleanText(trackingNote,500)||'';
  await rental.save();
  if (status==='returned') await Product.findOneAndUpdate({ _id:rental.product,owner:req.user.id },{ $set:{ available:true } });
  res.json({ rental:rentalView(rental) });
});
app.delete('/api/admin/rentals/:id',auth,adminOnly,async (req,res) => {
  if (!validId(req.params.id)) return fail(res,400,'Invalid rental ID.');
  const deleted=await Rental.findOneAndDelete({ _id:req.params.id,owner:req.user.id,status:'pending' });
  if (!deleted) return fail(res,404,'Pending order not found.');
  await Product.findOneAndUpdate({ _id:deleted.product,owner:req.user.id },{ $set:{ available:true } });
  res.json({ deleted:true });
});
app.get('/api/admin/summary',auth,adminOnly,async (req,res) => {
  const [total,active,pending,returned,products,customers]=await Promise.all([
    Rental.countDocuments({ owner:req.user.id }),Rental.countDocuments({ owner:req.user.id,status:{ $in:['active','maintenance','return_requested'] } }),Rental.countDocuments({ owner:req.user.id,status:'pending' }),Rental.countDocuments({ owner:req.user.id,status:'returned' }),Product.countDocuments({ owner:req.user.id,active:true }),Rental.distinct('customer',{ owner:req.user.id })
  ]);
  res.json({ total,active,pending,returned,products,customers:customers.length });
});
app.post('/api/developer/admins',auth,developerOnly,async (req,res) => {
  const name=cleanText(req.body?.name,80),email=typeof req.body?.email==='string'?req.body.email.trim().toLowerCase():'',password=req.body?.password;
  if (!name || name.length<2 || !validEmail(email) || typeof password!=='string' || password.length<8 || Buffer.byteLength(password,'utf8')>72) return fail(res,400,'Enter a valid name, email, and password (8–72 bytes).');
  if (await User.exists({ email })) return fail(res,409,'An account with this email already exists.');
  const user=await User.create({ name,email,passwordHash:await bcrypt.hash(password,12),role:'admin' });
  res.status(201).json({ admin:{ id:user.id,name:user.name,email:user.email } });
});
app.get('/api/developer/stats',auth,developerOnly,async (_req,res) => {
  const [customers,adminCount,admins,customerGroups,productCounts]=await Promise.all([
    User.countDocuments({ role:'customer' }),User.countDocuments({ role:'admin' }),User.find({ role:'admin' }).select('name email storeName storeCity').sort({ createdAt:-1 }).limit(250).lean(),
    Rental.aggregate([{ $group:{ _id:{ owner:'$owner',customer:'$customer' } } },{ $group:{ _id:'$_id.owner',count:{ $sum:1 } } }]),
    Product.aggregate([{ $match:{ active:true } },{ $group:{ _id:'$owner',count:{ $sum:1 } } }])
  ]);
  const customerMap=new Map(customerGroups.map((x)=>[String(x._id),x.count])),productMap=new Map(productCounts.map((x)=>[String(x._id),x.count]));
  res.json({ customers,admins:adminCount,stores:admins.map((a)=>({ id:String(a._id),name:a.name,email:a.email,storeName:a.storeName,storeCity:a.storeCity,customers:customerMap.get(String(a._id))||0,products:productMap.get(String(a._id))||0 })) });
});

app.use('/api',(_req,res)=>fail(res,404,'API endpoint not found.'));
if (isProduction) {
  const dist=path.resolve(here,'../dist');
  app.use(express.static(dist,{ dotfiles:'deny',index:false,maxAge:'1h' }));
  app.get('*',(_req,res)=>res.sendFile(path.join(dist,'index.html')));
}
app.use((err,_req,res,_next) => {
  console.error('Request failed:',err.message);
  if (err instanceof multer.MulterError) return fail(res,400,'Image upload was rejected. Choose one image under 5 MB.');
  if (err.message==='Unsupported image type') return fail(res,400,'Use a JPEG, PNG, WebP, or AVIF image.');
  const status=Number.isInteger(err.status)&&err.status>=400&&err.status<500?err.status:500;
  const message=status===413?'Request is too large.':status===400?'Invalid request.':'Something went wrong. Please try again.';
  res.status(status).json({ error:message });
});

async function start() {
  if (!process.env.MONGODB_URI || !process.env.JWT_SECRET) throw new Error('MONGODB_URI and JWT_SECRET must be configured.');
  await mongoose.connect(process.env.MONGODB_URI);
  if (process.env.DEVELOPER_EMAIL && process.env.DEVELOPER_PASSWORD) {
    const email=process.env.DEVELOPER_EMAIL.trim().toLowerCase(),password=process.env.DEVELOPER_PASSWORD;
    if (Buffer.byteLength(password,'utf8')<8 || Buffer.byteLength(password,'utf8')>72) throw new Error('DEVELOPER_PASSWORD must be between 8 and 72 bytes.');
    await User.findOneAndUpdate({ email },{ $set:{ name:'RentEase Developer',email,passwordHash:await bcrypt.hash(password,12),role:'developer' } },{ upsert:true,new:true,setDefaultsOnInsert:true });
  }
  // Keep support for an explicitly configured initial admin account during migration.
  if (process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD) {
    const email=process.env.ADMIN_EMAIL.trim().toLowerCase(),password=process.env.ADMIN_PASSWORD;
    await User.findOneAndUpdate({ email },{ $set:{ name:'RentEase Admin',email,passwordHash:await bcrypt.hash(password,12),role:'admin' } },{ upsert:true,new:true,setDefaultsOnInsert:true });
  }
  app.listen(port,()=>console.log(`RentEase listening on ${port}`));
}
start().catch((error)=>{ console.error('Startup failed:',error.message);process.exit(1); });






