# RentEase

Responsive, multi-shop furniture and appliance rental platform built with React, Express, and MongoDB. Product images are uploaded by shop admins to Cloudinary.

## Roles and workflows

- **Customer:** browse local rental shops, choose a shop, browse its items, submit a delivery request, and view only their own rentals and day-based accrued-rent estimates.
- **Admin:** one account owns one shop profile and its listings. The shop admin sees only orders and inventory attached to that account. They call the customer using the supplied phone number, then confirm the request or reject and delete a pending order. Confirmed rentals start day-based charge tracking.
- **Developer:** a single operator account bootstrapped from environment variables can create admin accounts and see aggregate customer/admin/shop statistics. It does not provide a customer PII browser.

Admins are provisioned by the developer rather than by public self-registration. After signing in, each admin completes their shop name, short description, city, and contact phone before their storefront appears to customers. Shop cards are ordered by distinct customers who have placed a rental with that shop.

Rejected pending orders are deleted and the product is made available again. Confirmed and returned rentals remain for customer history and admin statistics. A pending order does not accrue rent; approval starts charging at monthly rent divided by 30 for each completed 24-hour period. There are no payment options or payment collection.

## Run locally

1. Install Node.js 20 or later.
2. Copy `.env.example` to `.env`; set MongoDB, JWT, developer, and Cloudinary variables.
3. Install packages and run both services:

   ```sh
   npm install
   npm run dev
   ```

4. Open `http://localhost:5173`. Vite proxies `/api` to the Express server on port `10000`.

The developer account is created or refreshed from `DEVELOPER_EMAIL` and `DEVELOPER_PASSWORD` at server startup. Keep these secrets private and never commit `.env`.

## Deploy on Render

The included `render.yaml` configures a single web service. Set these secrets in the Render environment before deployment:

- `MONGODB_URI`: Atlas URI for a restricted database user and named database.
- `JWT_SECRET`: long random signing secret (Render can generate one through the blueprint).
- `DEVELOPER_EMAIL` and `DEVELOPER_PASSWORD`: private platform-operator account credentials.
- `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET`: Cloudinary credentials. The API secret stays on the server; browser uploads go through the authenticated, rate-limited backend.
- `TRUST_PROXY`: exact number of trusted reverse proxy hops. The Render blueprint sets this to `1`; adjust to match the actual topology.

Restrict MongoDB Atlas network access to the Render service's permitted outbound IPs or private network path. Avoid a broad public allowlist. MongoDB credentials are read only by the backend and are never sent to the browser.

## Environment variables

| Variable | Required | Purpose |
|---|---|---|
| `MONGODB_URI` | Yes | MongoDB/Atlas connection string |
| `JWT_SECRET` | Yes | Signs customer, admin, and developer sessions |
| `DEVELOPER_EMAIL` | Yes for admin provisioning | Bootstraps the developer dashboard account |
| `DEVELOPER_PASSWORD` | Yes for admin provisioning | Bootstraps developer sign-in |
| `CLOUDINARY_CLOUD_NAME` | For photo upload | Cloudinary cloud identifier |
| `CLOUDINARY_API_KEY` | For photo upload | Cloudinary API key |
| `CLOUDINARY_API_SECRET` | For photo upload | Cloudinary server-side secret |
| `PORT` | No | HTTP port; defaults to `10000` |
| `CLIENT_ORIGIN` | No | Explicit comma-separated origin allowlist only when hosting the frontend separately |
| `TRUST_PROXY` | No | Trusted proxy hop count; defaults to `1` in production |
| `NODE_ENV` | No | Set to `production` on Render |

## Security and performance

- API requests are limited to 300 per IP per 15 minutes; registration/sign-in to 10 per IP per 15 minutes; image uploads to 20 per IP per 15 minutes. The default limiter store is in-memory per process, so use a shared store if scaling to multiple server instances.
- Helmet security headers and a Content Security Policy are enabled. Cross-origin access is off unless an explicit origin allowlist is configured.
- Admin and developer APIs are role-protected. Shop rental and inventory queries are scoped to the signed-in admin. The public API returns only storefront fields, never customer or order records.
- Inputs are normalized, length-bounded, and type/format checked; uploaded images are limited to 5 MB and accepted only for JPEG, PNG, WebP, or AVIF MIME types.
- Image uploads use authenticated server-side Cloudinary upload; delivery URLs use automatic format/quality and bounded dimensions. Frontend product images load lazily, and catalog/admin list sizes are capped.
- Error responses are generic. Stack traces and database errors are not returned to clients.
- MongoDB indexes support shop inventory and order views.

## Policy pages

The footer links to Terms of Use, Privacy Policy, IP Infringement, and Data Use & Compliance pages. They are draft policies until the business identity, jurisdiction, monitored contacts, retention schedule, and provider locations are completed and reviewed.

## Data model and migration

Each product belongs to one admin (`owner`), and each rental snapshots that same owner. The app does not automatically assign existing unowned catalog products or legacy rentals to an admin: review/migrate any existing MongoDB data before deploying this multi-shop version. Product images for listings must be uploaded through the admin interface to Cloudinary.
