import React from 'react';
import { ArrowLeft, FileText, ShieldCheck, Copyright, Database } from 'lucide-react';

const docs = {
  terms: {
    title: 'Terms of Use', icon: FileText,
    intro: 'These draft terms explain the basic rules for using RentEase. The business owner must complete the contact and governing-law fields and have the terms reviewed for the places where RentEase will operate before launch.',
    sections: [
      ['1. About RentEase', ['RentEase is a platform for browsing furniture and appliances and requesting monthly rentals. The entity operating the service is [insert legal business name], with contact details at [insert monitored contact email and postal address].']],
      ['2. Accounts and acceptable use', ['Give accurate account and delivery information, keep your sign-in credentials private, and tell us if you believe your account has been used without permission. Do not misuse the service, interfere with its operation, or submit unlawful or misleading content. You are responsible for activity carried out through your account, subject to rights that cannot be excluded by law.']],
      ['3. Rental requests and approval', ['A request is not an approved rental. While a request is pending, RentEase may hold the selected catalog item while an shop owner reviews it. The administrator may approve or decline the request. An approved rental begins at the approval time recorded in the service; the item, address, monthly price, deposit shown, and rental status are recorded in your account. A separate rental agreement or order confirmation may set additional terms.']],
      ['4. Rental charges and deposits', ['This version does not accept payments or store payment-card or bank-account details. It displays an informational accrued-rent estimate after approval: monthly rent divided by 30, multiplied by completed 24-hour periods. Amounts are rounded for display. Accrual continues during maintenance and while a pickup request is pending, and stops when an administrator records the item as returned. The displayed estimate is not a receipt, invoice, payment demand, or confirmation that funds have been collected. Any actual payment, deposit, tax, cancellation, extension, late-return, refund, or damage terms must be provided separately before a paid rental is offered.']],
      ['5. Product information and availability', ['We aim to keep product descriptions, prices, images, and availability current, but catalog items may become unavailable and details may change. A request is subject to review and confirmation. Product images and descriptions are illustrative unless the item listing says otherwise.']],
      ['6. Returns, care, and support', ['Follow the care and safety information provided with an item. You may request a pickup through your account when that feature is available. A pickup request alone does not mark the item returned or stop the displayed accrual; the recorded return status does. Report damage or safety concerns through [insert monitored support channel].']],
      ['7. Intellectual property', ['RentEase and its licensors retain rights in the service and its original content. Do not copy or use protected content without permission. See our IP Infringement page to report a concern.']],
      ['8. Service availability and liability', ['The service is provided subject to applicable law. We do not promise uninterrupted availability. Nothing in these terms limits a consumer right or liability that cannot lawfully be limited. Any permitted limits of liability and warranty terms must be reviewed and completed for the operating jurisdiction before launch.']],
      ['9. Changes and governing law', ['We may update these terms by posting a revised version with a new effective date. The governing law, courts, dispute process, effective date, and operator identity must be completed by the business owner after deciding where the service will operate.']]
    ]
  },
  privacy: {
    title: 'Privacy Policy', icon: ShieldCheck,
    intro: 'This draft describes the current RentEase application. Replace the operator and contact placeholders and confirm actual hosting regions, retention periods, and legal requirements before publishing it as a final notice.',
    sections: [
      ['1. Who operates RentEase', ['The service operator is [insert legal business name]. For privacy questions or requests, contact [insert privacy contact email and postal address].']],
      ['2. Information the current app handles', ['Account information: name, email address, phone number, and a password hash. The app hashes passwords before storing them; it does not store the original password.', 'Rental information: selected shop/admin, product and category, monthly rent and deposit snapshots, request and approval/return times, status, delivery address, and optional administrator tracking notes. Customer phone is shared with the selected shop admin so they can call to confirm the request.', 'Session information: the browser stores a sign-in token and basic account details in local storage. The token expires after seven days; signing out clears these local values.', 'The current app does not request or collect payment-card or bank-account details, does not include online payment processing, and does not collect GPS or connected-appliance telemetry. “Monitoring” currently means rental status and administrator-entered notes.']],
      ['3. Why information is used', ['We use account details to create and secure accounts; rental and address details to review requests and coordinate delivery, rental status, and return; and service records to operate and support the platform. The app calculates accrued rent from the approval timestamp and saved monthly price. This estimate is not a payment transaction.']],
      ['4. Where information is stored and shared', ['Product photos are sent by the authenticated admin to Cloudinary for image storage and optimized delivery. The application is designed to use MongoDB and may be hosted on Render when deployed. The operator configures the database and hosting accounts, access controls, and regions. Those providers may process data to provide infrastructure services. Actual regions and any other recipients must be confirmed by the operator before launch. The current app has no analytics SDK or advertising SDK.']],
      ['5. Retention and your choices', ['The current version has no automatic account deletion, retention schedule, or self-service data export. Rental records remain in the database until an authorized operator removes them. To ask for access, correction, deletion, or another privacy request, contact [insert privacy contact email]. Some records may need to be retained where the law permits or requires it. The operator must define and implement a retention and request-handling process before production use.']],
      ['6. Security', ['The app hashes passwords and uses expiring signed session tokens. Protect your account credentials and sign out on shared devices. The operator must configure HTTPS, restrict production access, protect environment variables, and select appropriate database backups and access controls. No internet service can guarantee absolute security.']],
      ['7. Cookies and similar storage', ['The current app uses browser local storage for the sign-in token and account display details. It does not currently use an authentication cookie. The hosting provider or future integrations may use additional technologies; update this notice if that changes.']],
      ['8. Children and changes', ['The service is intended for adults arranging household rentals and is not designed for children. If the service changes to address minors, update the age and consent process. We may update this notice when the service or applicable requirements change.']],
      ['9. Rights and complaints', ['Privacy rights depend on where you live and where the service operates. Contact [insert privacy contact email] to raise a request or complaint. The operator should insert any required regulator or complaint route after confirming applicable law.']]
    ]
  },
  ip: {
    title: 'IP Infringement', icon: Copyright,
    intro: 'Please use this process to report content on RentEase that you believe infringes your copyright, trademark, or other intellectual-property rights. Submitting a report does not guarantee removal; we may ask for more information.',
    sections: [
      ['How to submit a report', ['Send a notice to [insert monitored IP contact email and postal address]. Include: (1) your name and contact details; (2) the right you own or are authorized to represent; (3) a description of the work or mark; (4) the exact RentEase listing, image, text, or URL at issue; (5) why you believe the use is unauthorized; and (6) a statement that your report is accurate and that you are the rights-holder or authorized representative. Include an electronic or physical signature.']],
      ['What we may do', ['We may review the notice, temporarily disable access to identified material, contact the account or supplier that provided it, and request further information. We may restore material if a claim is withdrawn or does not establish a basis for continued restriction. We may restrict repeat misuse where appropriate and lawful.']],
      ['Good-faith reporting', ['Only submit information you believe to be accurate. A false or abusive claim may have legal consequences. Do not include unnecessary personal or confidential information in a notice.']],
      ['United States DMCA notices', ['If the operator intends to rely on the U.S. DMCA safe-harbor process, it must appoint and register a designated agent with the U.S. Copyright Office and publish that agent’s current contact details. The operator has not supplied a registered agent for this project. Complete this section and registration before claiming a DMCA agent or relying on that process. This general reporting address is not, by itself, a registered DMCA designation.']],
      ['Contact', ['IP contact: [insert monitored email and postal address]. Replace this placeholder before publishing the policy.']]
    ]
  },
  data: {
    title: 'Data Use & Compliance', icon: Database,
    intro: 'This page describes the data and controls in the current application so customers and operators can see what is implemented and what still needs operational setup. It is not a certification or a claim that the business complies with every law.',
    sections: [
      ['Data handled by this version', ['The database stores customer name, email, password hash, requested product, price and deposit snapshots, delivery address, rental status, approval and return timestamps, and optional admin tracking notes. Accrued rent is calculated from stored values when requested; it is not currently stored as a payment or ledger transaction.', 'The system does not collect payment credentials, process payments, use GPS tracking, or connect to smart-appliance telemetry. Admin “monitoring” is a status and note workflow.']],
      ['Current technical safeguards', ['Passwords are hashed with bcrypt. API requests use signed tokens that expire after seven days, and admin API routes check the user role. MongoDB credentials and the signing secret are supplied through environment variables. Production transport security and database access/network rules must be configured by the deployment operator.']],
      ['Operator responsibilities still to complete', ['Choose the operating countries and applicable privacy, consumer, rental, tax, and records laws.', 'Complete the legal operator identity, support/privacy contacts, retention schedule, and deletion/export request process.', 'Configure MongoDB and Render account access, backups, regions, HTTPS, and incident response; document which providers and locations process data.', 'Review the authorization and operational workflows, including admin access, before inviting real customers.', 'Have counsel review the privacy notice, rental terms, and IP process.']],
      ['No compliance certification', ['Using this application does not itself establish compliance with the GDPR, India’s Digital Personal Data Protection Act, or any other regime. Applicability and commencement can depend on the operator, users, and location. Confirm the requirements that apply and update both the service and this notice before launch.']],
      ['Contact', ['For a data question or request, contact [insert privacy contact email and postal address]. This placeholder must be replaced with a monitored channel.']]
    ]
  }
};

export function LegalPage({type,onBack}) {
  const doc=docs[type]||docs.terms; const Icon=doc.icon;
  return <section className="legal-page">
    <button className="legal-back" onClick={onBack}><ArrowLeft size={15}/> Back to RentEase</button>
    <div className="legal-heading"><span className="legal-icon"><Icon size={21}/></span><div><div className="eyebrow">RENTEASE · POLICY CENTRE</div><h1>{doc.title}</h1></div></div>
    <div className="legal-draft"><strong>Draft policy</strong><span>Owner details, jurisdiction, and contact fields must be completed before public launch.</span></div>
    <p className="legal-intro">{doc.intro}</p>
    <div className="legal-sections">{doc.sections.map(([heading,items])=><section className="legal-section" key={heading}><h2>{heading}</h2>{items.length>1&&type==='privacy'&&heading==='2. Information the current app handles'?<ul>{items.map(x=><li key={x}>{x}</li>)}</ul>:items.map((x,i)=><p key={i}>{x}</p>)}</section>)}</div>
  </section>
}



